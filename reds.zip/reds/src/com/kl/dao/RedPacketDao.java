package com.kl.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.kl.pojo.RedPacket;


@Repository
public interface RedPacketDao {
	/**
	 * 获取红包
	 * @param id
	 * @return
	 */
	public RedPacket getRedPacket(Long id);
	/**
	 * 扣减红包
	 * @param id
	 * @return
	 */
	public int decreaseRedPacket(Long id);
	/**
	 * 乐观锁
	 * @param id
	 * @return
	 */
	public int decreaseRedPacketForVersion(@Param("id") Long id, @Param("version") Integer version);
}
