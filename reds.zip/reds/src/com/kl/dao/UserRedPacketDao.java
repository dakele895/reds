package com.kl.dao;


import org.springframework.stereotype.Repository;

import com.kl.pojo.UserRedPacket;
@Repository
public interface UserRedPacketDao {
	/**
	 * 插入抢红包信息
	 * @param userRedPacket
	 * @return
	 */
	public int grapRedPacket(UserRedPacket userRedPacket);
	
}
