package com.kl.service;



public interface UserRedPacketService {
	/**
	 * 插入抢红包信息
	 * @param userRedPacket
	 * @return
	 */
	public int grapRedPacket(Long redPacketId,Long userId);
	/**
	 * 乐观锁
	 * @param id
	 * @return
	 */
	public int grapRedPacketForVersion(Long redPacketId, Long userId);
	/**
	 * 通过redis实现抢红包
	 * @param redPacketId 红包编号
	 * @param userId 用户编号
	 * @return
	 * 没有库存则失败
	 * 1.成功
	 * 2.最后一个红包
	 */
	public Long grapRedPacketByRedis(Long redPacketId, Long userId);
}
